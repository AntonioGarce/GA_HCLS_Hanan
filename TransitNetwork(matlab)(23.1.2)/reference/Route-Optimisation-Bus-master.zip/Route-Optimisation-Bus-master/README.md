# Route-Optimisation-for-Public-Transport-System
Route Optimization for Public Transport using genetic algorithms
