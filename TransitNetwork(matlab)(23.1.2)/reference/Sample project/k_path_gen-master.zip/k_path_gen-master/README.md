[readme]

The scripts in this packet is to generate k shortest path between every pair of nodes in a network. The source code used to generate k-shortest paths are from http://www.mathworks.com/matlabcentral/fileexchange/32513-k-shortest-path-yen-s-algorithm, based on Yen's k-shortest path algorithm, and it was used for a single pair. 

This packet of scripts provides a wrapper to generate k-shortest path for all possible pair s of nodes in a network. For details, please see the enclosed guide file: path-generation-guide. 

