%%{
clear
close all 
clc


%% Load matricies 
%load('Mandl_data.mat')
load('KRAKOW_data_final.mat')
geration=0;Parent=[];
min_TF=inf;
MandlTravelTimes=KRAKOWTravelTimes;
MandlDemand=KRAKOWDemand;
total_passnger=sum(sum(MandlDemand));
weight=lt(KRAKOWTravelTimes,1000);    %make weight matrix to detrmine the links between nodes

%% Graph Construction 
G=graph(weight,'omitselfloops');

%% Travel Time and Demand extraction for all existente links
for a = 1 : height(G.Edges)
    garbage.s = G.Edges.EndNodes(a,1);
    garbage.t = G.Edges.EndNodes(a,2);
    garbage.Z(a,:) = KRAKOWTravelTimes(garbage.s,garbage.t); % get
    garbage.D(a,:) = KRAKOWTravelTimes(garbage.s,garbage.t);
 end
G.Edges.Time = garbage.Z(:,1);
G.Edges.Demand = garbage.D(:,1);
%%
hh= plot((G),'Markersize',4);%,'XData',(No_name(:,1)),'YData',(No_name(:,2)));  %plot the graph
%% End points coordinates and extra data migration to G object
for i=1:length(NO_station)
names11{i}=num2str(NO_station(i));

end
%%}
for i=1:length(NO_station)
labelnode(hh,i,[names11{i}])
end

No_Routs=22;
title('Orignal KRAKOW part node')
%}
Parent={[125,	124,	123,	122,	121,	120,	119,	118,	117,...
    103,	116,	115,	885,	112,	452,	814,	813,	812,...
    811,	810,	809,	808,	807,	806,	821,	822,	823,...
    300,	301], [301,	300,	823,	822,	827,	833,	801,	851,...
    852,	853,	854], [702,	657,	656,	655,	649,	648,	647,...
    646,	645,	644,	643,	642,	640,	816,	815,	807,...
    806,	801,	760,	839,	381,	382,	383,	416],[125,	124,...
    123,	122,	194,	193,	107,	106,	105,	104,	103,...
    102,	101,	100,	805,	804,	803,	802,	851,	801,...
    833,	827,	828,	829,	354,	355,	356,	169,	357,...
    358,	359,	360],[125,	124,	123,	122,	121,	120,	119,...
    118,	117,	103,	102,	101,	100,	805,	804,	803,	802,...
    901,	839,	381,	382,	383,	416],[584,	583,	627,	634,...
    635,	646,	645,	644,	643,	642,	641,	556,	820,...
    819,	818,	817,	821,	822,	824,	825,	345,	453,	346,	347],[562,	743,	561,	553,	559,	558,	557,	556,	820,	819,	818,	817,	821,	822,	827,	828,	829,	354,	355,	356,	169,	357,	358,	359,	360],[139,	140,	141,	143,	161,	162,	135,	118,	117,	103,	102,	101,	100,	805,	804,	803,	802,	809,	619,	294,	670,	671,	674,	501,	645,	646,	647,	648,	649,	655,	656,	657,	702],[218,	217,	216,	215,	214,	213,	889,	212,	107,	106,	105,	104,	103,	102,	101,	100,	805,	804,	803,	802,	851,	801,	806,	817,	818,	819,	820,	556,	557,	558,	559,	553],[711,	678,	674,	501,	644,	643,	642,	641,	556,	557,	558,	559,	553,	552,	551,	528,	526,	527,	706,	291,	292,	293],[702,	657,	656,	655,	649,	648,	647,	646,	645,	644,	643,	642,	641,	556,	820,	819,	818,	817,	821,	822,	827,	828,	829,	354,	355,	356,	169,	357],[139,	140,	141,	143,	161,	162,	135,	118,	117,	103,	116,	115,	885,	112,	452,	814,	813,	812,	811,	810,	809,	802,	851,	801,	833,	827,	828,	829,	354,	355,	356,	169,	357],[293,	292,	291,	706,	527,	526,	528,	551,	552,	553,	559,	558,	557,	556,	640,	816,	815,	807,	808,	809,	802,	901,	839,	381],[293,	292,	291,	706,	527,	526,	528,	525,	524,	523,	522,	501,	872,	819,	818,	817,	821,	822,	827,	833,	834,	835,	381,	382,	383,	416],[562,	743,	561,	553,	559,	558,	557,	556,	640,	816,	815,	807,	808,	809,	802,	901,	839,	381],[711,	678,	674,	671,	670,	294,	619,	809,	802,	851,	801,	833,	827,	824,	825,	345,	453,	346,	347],[218,	217,	216,	215,	214,	213,	889,	212,	107,	106,	105,	136,	118,	135,	162,	161,	144,	147,	148],[562,	743,	561,	553,	552,	551,	525,	524,	523,	522,	501,	872,	819,	807,	808,	809,	810,	811,	812,	813,	814,	452,	112,	885,	115,	116,	103,	104,	105,	106,	107,	212],[584,	583,	627,	634,	635,	646,	645,	644,	643,	642,	640,	816,	815,	807,	806,	801,	833,	827,	828,	829,	354,	355,	356,	169,	357,	358,	359,	360],[702,	657,	656,	655,	649,	648,	647,	646,	645,	501,	674,	671,	670,	294,	619,	809,	802,	803,	804,	805],[416,	383,	382,	381,	839,	901,	802,	809,	619,	294,	670,	671,	674,	501,	645,	646,	635,	634,	627,	583,	584],[293,	292,	291,	706,	527,	526,	528,	525,	524,	523,	522,	501,	872,	819,	807,	806,	801,	851,	802,	803,	804,	805,	100,	101,	102,	103,	117,	118,	135,	162,	161,	144,	147,	148]};


No_HCLS=4; 
No_swap=floor(No_Routs/2);
Maxit=1;
% w for PT
wp1=0.6;wp2=0.3;wp3=0.1;
% w for TF
w1=0.2;w2=0.8;w3=0;
P1=5;P2=17;geration=1;No_Routs=20;
for it=1:Maxit
for ge=1:geration
[Parentresult]=FFTT(Parent,No_Routs,P1,P2);
Parentres.ddo=Parentresult.ddo;
Parentres.PTo=Parentresult.PTo;
Parentres.TIVT=Parentresult.TIVT;
Parentres.Total_trans=Parentresult.Total_trans;
Parentres.ontrans=Parentresult.ontrans;
Parentres.P_T1=Parentresult.P_T1;
Parentres.PT1=Parentresult.PT1;
Parentres.dd1=Parentresult.dd1;
Parentres.tworans=Parentresult.tworans;
Parentres.T2=Parentresult.T2;
Parentres.P_T2=Parentresult.P_T2;
Parentres.dd2=Parentresult.dd2;
Parentres.PT2=Parentresult.PT2;
Parentres.ATT=((Parentres.P_T1+Parentres.P_T2+Parentres.TIVT)/total_passnger)*5;
Parentres.PT=(-wp1*Parentres.PTo+wp2*Parentres.PT1+wp3*Parentres.PT2)/total_passnger;
Parentres.TF=(w1*Parentres.ATT+w2*Parentres.PT);

if min_TF>Parentres.TF
  min_TF=Parentres.TF ;
  Globel.best=Parentres;
  Globel.ddopercent=Parentres.ddo/(Parentres.ddo+Parentres.dd1+Parentres.dd2)*100;
 Globel.dd1percent=Parentres.dd1/(Parentres.ddo+Parentres.dd1+Parentres.dd2)*100;
 Globel.dd2percent=Parentres.dd2/(Parentres.ddo+Parentres.dd1+Parentres.dd2)*100;
Globel.MIN_TF=min_TF;
Globel.ATT=Parentres.ATT;
end
end
end
