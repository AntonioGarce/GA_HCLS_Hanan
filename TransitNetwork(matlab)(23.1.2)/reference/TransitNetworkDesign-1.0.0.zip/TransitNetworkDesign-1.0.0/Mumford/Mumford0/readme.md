# Mumford0 Instance

![](Mumford0.png)
