# Mumford3 Instance

![](Mumford3.png)
