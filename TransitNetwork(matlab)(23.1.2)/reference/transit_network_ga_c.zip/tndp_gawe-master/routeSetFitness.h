/* 
 * File:   routeSetFitness.h
 * Author: MAN
 *
 * Created on September 7, 2013, 7:52 AM
 */

#ifndef _ROUTESETFITNESS_H
#define	_ROUTESETFITNESS_H



#endif	/* _ROUTESETFITNESS_H */

